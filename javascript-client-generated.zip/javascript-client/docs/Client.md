# CatbsRestApi.Client

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**active** | **Boolean** |  | [optional] 
**email** | **String** |  | [optional] 
**id** | **Number** |  | [optional] 
**login** | **String** |  | [optional] 


