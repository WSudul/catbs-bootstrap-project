# CatbsRestApi.SeatOrder

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderType** | [**OrderType**](OrderType.md) |  | [optional] 
**price** | [**Price**](Price.md) |  | [optional] 
**reservation** | [**Reservation**](Reservation.md) |  | [optional] 
**seatOrderKey** | [**SeatOrderKey**](SeatOrderKey.md) |  | [optional] 


