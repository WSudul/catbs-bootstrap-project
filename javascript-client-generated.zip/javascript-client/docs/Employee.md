# CatbsRestApi.Employee

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**active** | **Boolean** |  | [optional] 
**firstname** | **String** |  | [optional] 
**id** | **Number** |  | [optional] 
**kinoId** | **Number** |  | [optional] 
**lastname** | **String** |  | [optional] 
**login** | **String** |  | [optional] 
**position** | **String** |  | [optional] 


