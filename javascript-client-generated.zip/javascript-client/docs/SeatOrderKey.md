# CatbsRestApi.SeatOrderKey

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reservationId** | **Number** |  | [optional] 
**seatId** | **Number** |  | [optional] 


