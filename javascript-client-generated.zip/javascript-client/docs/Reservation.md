# CatbsRestApi.Reservation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**active** | **Boolean** |  | [optional] 
**clientId** | **Number** |  | [optional] 
**createTime** | [**Timestamp**](Timestamp.md) |  | [optional] 
**employeeId** | **Number** |  | [optional] 
**id** | **Number** |  | [optional] 
**paid** | **Boolean** |  | [optional] 
**paidEmployeeId** | **Number** |  | [optional] 
**screeningId** | **Number** |  | [optional] 
**seatOrders** | [**[SeatOrder]**](SeatOrder.md) |  | [optional] 


