# CatbsRestApi.Genre

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**genre** | **String** |  | [optional] 
**id** | **Number** |  | [optional] 
**movies** | [**[Movie]**](Movie.md) |  | [optional] 


