# CatbsRestApi.Schedule

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**archived** | **Boolean** |  | [optional] 
**dateEnd** | **Date** |  | [optional] 
**dateStart** | **Date** |  | [optional] 
**id** | **Number** |  | [optional] 
**kinoId** | **Number** |  | [optional] 
**screenings** | [**[Screening]**](Screening.md) |  | [optional] 


