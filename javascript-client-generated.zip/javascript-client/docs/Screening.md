# CatbsRestApi.Screening

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**auditoriumId** | **Number** |  | [optional] 
**id** | **Number** |  | [optional] 
**movieId** | **Number** |  | [optional] 
**scheduleId** | **Number** |  | [optional] 
**scheduleKinoId** | **Number** |  | [optional] 
**start** | [**Timestamp**](Timestamp.md) |  | [optional] 


