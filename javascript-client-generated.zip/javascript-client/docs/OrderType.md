# CatbsRestApi.OrderType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**discount** | **Number** |  | [optional] 
**id** | **Number** |  | [optional] 
**type** | **String** |  | [optional] 


