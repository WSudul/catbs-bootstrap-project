# CatbsRestApi.ClientLoginData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**active** | **Boolean** |  | [optional] 
**login** | **String** |  | [optional] 
**password** | **String** |  | [optional] 
**salt** | **String** |  | [optional] 


