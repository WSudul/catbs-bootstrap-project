# CatbsRestApi.ClientRegistration

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**active** | **Boolean** |  | [optional] 
**answer** | **String** |  | [optional] 
**email** | **String** |  | [optional] 
**login** | **String** |  | [optional] 
**password** | **String** |  | [optional] 
**question** | **String** |  | [optional] 
**salt** | **String** |  | [optional] 


