# CatbsRestApi.Movie

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**active** | **Boolean** |  | [optional] 
**ageRestriction** | **Number** |  | [optional] 
**description** | **String** |  | [optional] 
**director** | **String** |  | [optional] 
**genres** | [**[Genre]**](Genre.md) |  | [optional] 
**id** | **Number** |  | [optional] 
**imagePath** | **String** |  | [optional] 
**info** | **String** |  | [optional] 
**language** | **String** |  | [optional] 
**length** | **Number** |  | [optional] 
**originalTitle** | **String** |  | [optional] 
**releaseDate** | **Date** |  | [optional] 
**title** | **String** |  | [optional] 
**type** | **String** |  | [optional] 


